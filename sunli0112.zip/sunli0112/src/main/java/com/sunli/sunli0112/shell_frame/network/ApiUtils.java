package com.sunli.sunli0112.shell_frame.network;

/**
 * 接口
 */
public class ApiUtils {
    public static final String get_Url_Shop_Car = "getCarts?uid=71&source=1.0.1";
}
