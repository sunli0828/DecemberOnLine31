package com.sunli.sunli0112.shell_frame.mvp.view;

/**
 * @Author sunli
 * @Data 2019/1/12
 */
public interface IView {
    void showResponseData(Object data);
    void showResponseFail(String e);
}
